print("""
\t1. feladat: 	A mikulás manói olyan csomagoló papírt készítenek ami kézzel van megírva. Mondanak két egész számot és a köztük lévő negatív számokat hópehelyhekkel(*) elválasztva írják le.
pl.:  be: (-7,-2)  ki: -7*-6*-5*-4*-3*-2 
Az eljárást külön modulban valósítsd meg

""")
bekeres = int(input("Adjon meg az első egész számot: "))
bekeres2 = int(input("Adjon meg a második egész számot: "))

def kiiratas(minimum, maximum):
    for szam in range(minimum,maximum, 1):
        if szam == minimum:
            print(szam, end="")
        else:
            print(end="*"+str(szam))

if bekeres > bekeres2:
    kiiratas(bekeres2, bekeres+1)
elif bekeres < bekeres2:
    kiiratas(bekeres,bekeres2+1)