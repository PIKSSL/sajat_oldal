import harmadik_modul_elso
import harmadik_modul_masodik
import harmadik_modul_harmadik
import harmadik_modul_negyedik
print("""
A Mikulás nyilván tartást szeretne a rénszarvasairól. Minden feladatot külön eljárással valósíts meg külön modulba, amit a fő programból hívsz meg!
""")
hany = harmadik_modul_elso.hany
hanya = harmadik_modul_masodik.hanya
hanykarakter = harmadik_modul_harmadik.hanykarakter
nev = harmadik_modul_negyedik.nev


lista = [
"Comet – Üstökös",
"Cupid – Íjas",
"Vixen – Csillag",
"Dancer – Táncos",
"Prancer – Pompás",
"Blitzen – Villám",
"Dasher – Táltos",
"Donder – Ágas",
"Red Rudolph – Rudolf, a piros orrú"
]


hany(lista)
hanya(lista)
print(lista)
print(hany(lista))
print(hanya(lista))
print(hanykarakter(lista))
print(nev(lista))