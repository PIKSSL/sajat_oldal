def hany(lista):
    hany = 0
    for index in range(0, len(lista), 1):
        hany += 1
    return hany