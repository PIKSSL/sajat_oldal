def hanykarakter(lista):
    hanykarakter = 0
    for i in range (0, len(lista),1):
        hanykarakter += len(lista[i])

    return hanykarakter