def hanya(lista):
    hanya = 0
    for i in range (0, len(lista),1):
        for (hely, karakter) in enumerate(lista[i]):
            if karakter == "a":
                hanya +=1

    return hanya
