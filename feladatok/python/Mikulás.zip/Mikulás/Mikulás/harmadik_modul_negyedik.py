def nev(lista):
    hely = 0
    hossz = 0
    for i in range(0, len(lista),1):

        if len(lista[i]) > hossz:
            hossz = len(lista[i])
            hely = len(lista)
    return hossz, hely