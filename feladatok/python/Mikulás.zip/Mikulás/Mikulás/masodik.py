import random
import masodik_modul
print("""
2. feladat: 	A mikulás gyárban minden ajándék kategóriaazonosítót kap. Az a feladatot, hogy készíts egy 20 elemű véletlen számokból álló listát ami [-10, 80] közötti számokkal töltöd fel. A negatív számok a selejtes ajándékok kategóriákat jelentik.
""")

harmadik = masodik_modul.harmadik
selejt = masodik_modul.selejt
nemselejt = masodik_modul.nemselejt
legnagyobb = masodik_modul.legnagyobb

intervallum1 = int(input("Adja meg az intervallum alsó határát: "))
intervallum2 = int(input("Adja meg az intervallum felső határát: "))


if intervallum1 < intervallum2:
    rnd = random.randint(intervallum1,intervallum2)
else:
    rnd = random.randint(intervallum2,intervallum1)

lista = []
index = 1
#selejt = 0
#nemselejt = 0
azonosito= []
while index < 21:
    lista.append(rnd)
    rnd = random.randint(-10, 80)
    index+=1
selejt(lista)
nemselejt(lista)
legnagyobb(lista)
print("Ajándékok: "+str(lista))
print("Minden harmadik ajándék: "+str(harmadik(lista)))
print("Selejtes ajándékok: "+str(selejt(lista)))
print("Nem selejtes ajándékok: "+str(nemselejt(lista)))
print(legnagyobb(lista))