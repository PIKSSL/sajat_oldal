def harmadik(azonosito):
    kiirat = []
    for (hely,harmadik) in enumerate(azonosito):
        #print("\t"+str(harmadik))
        if hely % 3 == 2:
            kiirat.append(harmadik)
    return kiirat
def selejt(lista):
    selejt = 0
    for (hely, selejtek) in enumerate(lista):
        if selejtek < 0:
            selejt +=1
    return selejt

def nemselejt(lista):
    nemselejt = 0
    for (hely, nemselejtek) in enumerate(lista):
        if nemselejtek >= 0:
            nemselejt += 1
    return nemselejt

def legnagyobb(lista):
    szam = 0
    szam1 = 0
    helye = 0
    for (hely, legnagyobb) in enumerate(lista):
        szam = legnagyobb
        if szam > szam1:
            szam1 = legnagyobb
            helye = hely
    eredmeny = "A legnagyobb elem értéke: "+str(legnagyobb)+ " Helye: "+str(helye)
    return eredmeny
