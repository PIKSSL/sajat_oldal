from datetime import datetime
from genericpath import exists
import os


def hibakod1():
    global kerdes
    kerdes = int(input("|A következő opciók közül választhat|: \n[1]Naplózás inditása\n[2]Naplózás megtekintése\n[3]Naplózás törlése\n[4]Órabér beállítása\n[5]Kilépés\n>>"))
    while kerdes > 5 or kerdes < 1:
        print("HIBA:A választott opció nem létezik!")
        kerdes = int(input("|A következő opciók közül választhat|: \n[1]Naplózás inditása\n[2]Naplózás megtekintése\n[3]Naplózás törlése\n[4]Órabér beállítása\n[5]Kilépés\n>>"))

def ellenorzes():
    mappa = exists('naplo')
    if mappa == False:
        os.mkdir('naplo')
    fajl = exists('naplo/naplozas.txt')
    if fajl == False:
        open('naplo/naplozas.txt','w',encoding="utf-8")

def ora(kezdet, vege):
    ber = open('oraber.txt', 'r', encoding="utf-8")
    oraber = float(ber.read())
    ber.close()
    ido = ((kezdet-vege).total_seconds()/60)%60
    fizetes = float(oraber)*(ido)
    return f"{ido:.2f}, Fizetés: [{oraber:.2f}Ft/ó]:{fizetes:.2f}Ft"

def naplozas():
    global cselekves
    global jelenlegiido
    most = datetime.now()
    jelenlegiido = most.strftime("%H:%M:%S")
    cselekves = str(input("Mivel foglalkozik éppen? >> "))
    naplo = open('naplo/naplozas.txt','a',encoding="utf-8")
    naplo.writelines(jelenlegiido)
    naplo.write('--')
    naplo.write(cselekves)
    naplo.write('\n')
    naplo.close()

oraber = 0
ellenorzes()

i = 0
while not i == 1:
    hibakod1()
    if kerdes == 1:
        print("|Az 'exit' parancsal kiléphet a naplózásból|")
        kezdet = datetime.now()
        while not i == 1:
            naplozas()
            if cselekves == "exit":
                vege = datetime.now()
                print("Naplózás kezdete ekkor:", kezdet.strftime("%H:%M:%S"), "Naplózás befejezve ekkor:",vege.strftime("%H:%M:%S"), "Ledolgozott óra:", ora(vege, kezdet))
                print("A naplózás befejeződött!")
                break
    elif kerdes == 2:
        print("____________________________________")
        print("Naplózás:")
        naplo = open('naplo/naplozas.txt', 'r',encoding="utf-8")
        print(naplo.read())
        naplo.close()
        print("____________________________________")
    elif kerdes == 3:
        naplo = open('naplo/naplozas.txt','w',encoding="utf-8")
        naplo.write('')
        naplo.close()
        print("A naplózás sikeresen törölve lett!")
    elif kerdes == 4:
        oraber = float(input("Adja meg az órabérét számokkal (Ft/ó):\n>>"))
        mentes = open('oraber.txt','w',encoding="utf-8")
        mentes.write(str(oraber))
        mentes.close()
    elif kerdes == 5:
        exit()
